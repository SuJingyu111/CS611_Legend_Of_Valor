//Class for the game entity

public class LMH {

    private HeroFactory heroFactory;

    private int HERO_TEAM_SIZE_LIMIT;

    private int WORLD_SIZE_UPPER_LIMIT, WORLD_SIZE_LOWER_LIMIT;

    public LMH() {
        heroFactory = new HeroFactory();
        HERO_TEAM_SIZE_LIMIT = 3;
        WORLD_SIZE_UPPER_LIMIT = 1000;
        WORLD_SIZE_LOWER_LIMIT = 8;
    }

    public void play(){
        do {
            runGame();
        }
        while (ifPlayAgain());
        printEndingMsg();
    }

    public void runGame(){
        //System.out.println(1);
        printWelcomingMsg();
        HeroTeam heroTeam = createHeroTeam();
        heroTeam.showTeam();
        World world = generateWorld();
        world.placeHeroTeamInit();
        while (true) {
            world.display();
            Cell curCell = world.getCurCell();
            if (curCell instanceof Market) {
                for (Hero hero : heroTeam) {
                    proposePurchase(hero, (Market) curCell);
                }
            }
            else {
                //TODO
            }
            if (!heroTeam.isSober()) {
                System.out.println("All heros fainted! You lose!");
                break;
            }
            if (!takeNextMove(world)) {
                break;
            }
        }
    }

    private boolean ifPlayAgain() {
        System.out.println("Game ended! Do you want to play again? (Yes/No)");
        return Utils.takeYes();
    }

    private void printEndingMsg() {
        System.out.println("Thank you for playing Heroes And Monsters! Have a nice day!");
    }

    private void printWelcomingMsg() {
        System.out.println("Welcome to Heroes And Monsters!");
    }

    private HeroTeam createHeroTeam() {
        System.out.println("Start with creating your team of heroes of up to 3 members!");
        System.out.println("Hero types: " + heroFactory.getHeroTypeSet());
        HeroTeam heroTeam = new HeroTeam();
        for (int i = 0; i < HERO_TEAM_SIZE_LIMIT; i++) {
            System.out.println("Please select the type of the " + (i + 1) + "th hero");
            heroTeam.addHero(heroFactory.produceNewHero());
        }
        return heroTeam;
    }

    private World generateWorld() {
        System.out.println("Please enter the dimension of the world (default and minimum 8 * 8, enter one integer only): ");
        int dimension = Utils.takeInteger(WORLD_SIZE_LOWER_LIMIT, WORLD_SIZE_UPPER_LIMIT);
        System.out.println("Initializing world...");
        return new World(dimension);
    }

    private boolean takeNextMove(World world) {
        String input = takeNextMoveInput(world);
        if (input.equalsIgnoreCase("q")) {
            return false;
        }
        if (input.equalsIgnoreCase("w")) {
            if (!world.moveHeroTo(-1, 0)) {
                System.out.println("Out of Bound! Try again");
                return takeNextMove(world);
            }
            return true;
        }
        else if (input.equalsIgnoreCase("a")) {
            if (!world.moveHeroTo(0, -1)) {
                System.out.println("Out of Bound! Try again");
                return takeNextMove(world);
            }
            return true;
        }
        else if (input.equalsIgnoreCase("s")) {
            if (!world.moveHeroTo(1, 0)) {
                System.out.println("Out of Bound! Try again");
                return takeNextMove(world);
            }
            return true;
        }
        else {
            if (!world.moveHeroTo(0, 1)) {
                System.out.println("Out of Bound! Try again");
                return takeNextMove(world);
            }
            return true;
        }
    }

    private String takeNextMoveInput(World world) {
        System.out.println("Enter your next move (w/W, a/A, s/S, d/D, q/Q): ");
        String input = Utils.takeInput();
        if (!(input.equalsIgnoreCase("w") || input.equalsIgnoreCase("a") || input.equalsIgnoreCase("s")
                || input.equalsIgnoreCase("d") || input.equalsIgnoreCase("q"))) {
            System.out.println("Invalid input! Try again!");
            return takeNextMoveInput(world);
        }
        return input;
    }

    private void proposePurchase(Hero hero, Market market) {
        market.display();
        System.out.println("Hero " + hero.getName() + ", do you want to buy anything? (Yes/No)");
        if (Utils.takeYes()) {
            while (true) {
                System.out.println("What fo you want to buy? ");
                String input = Utils.takeInput();
                if (market.ifContains(input)) {
                    Item item = market.getItemByName(input);
                    if (hero.getMoney() < item.getPrice()) {
                        System.out.println("Insufficient fund! Try again.");
                    }
                    else {
                        hero.setMoney(hero.getMoney() - item.getPrice());
                        market.sold(input);
                        item.setPrice(item.getPrice() / 2);
                        hero.addToInventory(item);
                    }
                }
                else {
                    System.out.println("Invalid item name! Try again!");
                }
            }
        }
    }
 }
