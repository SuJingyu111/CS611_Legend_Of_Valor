//Class for monsters

public class Monster extends Figure {

    private int bounty;

}
