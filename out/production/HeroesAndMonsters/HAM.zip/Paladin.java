//Class for paladin

public class Paladin extends Hero {

    public Paladin(String[] args) {
        super(args);
    }

}
