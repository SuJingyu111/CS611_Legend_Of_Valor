//Class for cells that are not accessible

public class InaccessibleCell extends Cell{
}
