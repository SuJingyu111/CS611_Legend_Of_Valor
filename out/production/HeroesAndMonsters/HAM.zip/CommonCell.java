//A common cell with chances to create monsters

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CommonCell extends Cell {

    private List<Monster> monsters;

    private static MonsterFactory monsterFactory;

    public CommonCell() {
        monsters = new ArrayList<>();
        monsterFactory = MonsterFactory.getInstance();
    }

    public void rollDiceAndGenerateMonster(int monsterNum) {
        Random rand = new Random();
        if (rand.nextInt(10) < 4) {
            for (int i = 0; i < monsterNum; i++) {
                monsters.add(monsterFactory.produceNewMonster());
            }
        }
    }
}
