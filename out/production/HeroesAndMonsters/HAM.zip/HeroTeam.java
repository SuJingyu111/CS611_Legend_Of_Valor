//Team of heroes

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HeroTeam implements Iterable<Hero>{

    private List<Hero> heroes;

    public HeroTeam() {
        heroes = new ArrayList<>();
    }

    @Override
    public Iterator<Hero> iterator() {
        return heroes.iterator();
    }

    public void addHero(Hero hero) {
        heroes.add(hero);
    }

    public boolean isSober() {
        int faintedCnt = 0;
        for (Hero hero : heroes) {
            if (hero.getHp() == 0) {
                faintedCnt++;
            }
        }
        return faintedCnt != heroes.size();
    }

    public void showTeam() {
        System.out.println("Members of the team: ");
        System.out.println("Name/mana/strength/agility/dexterity/starting money/starting experience");
        for (Hero hero : heroes) {
            System.out.println(hero);
        }
        System.out.println("Good luck with the adventure!");
    }
}
