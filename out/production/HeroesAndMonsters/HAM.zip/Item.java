//Class for all items

public class Item {

    String type;

    private String name;

    private int price;

    private int minHeroLevel;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getMinHeroLevel() {
        return minHeroLevel;
    }

    public void setMinHeroLevel(int minHeroLevel) {
        this.minHeroLevel = minHeroLevel;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
