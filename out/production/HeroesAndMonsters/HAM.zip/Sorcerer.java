//Class for sorcerer

public class Sorcerer extends Hero{

    public Sorcerer(String[] args) {
        super(args);
    }
    
}
