//Class for lighning spells

public class LightningSpells extends Spell {

    private int baseDodgeChanceDeduction;

    public LightningSpells(String[] args) {
        super(args);
    }
}
