//Class for warriors

public class Warrior extends Hero {

    public Warrior(String[] args) {
        super(args);
    }
}
