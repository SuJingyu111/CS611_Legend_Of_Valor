//Class for monter spirit

public class Spirits extends Monster{
}
