//Inventory class for both hero and market

import java.util.ArrayList;
import java.util.List;

public class Inventory {

    List<Item> inventory;

    public Inventory() {
        inventory = new ArrayList<>();
    }

    public void add(Item item) {
        inventory.add(item);
    }

    public Item remove(String name) {
        Item removeItem = null;
        for (Item item : inventory) {
            if (item.getName().equals(name)) {
                removeItem = item;
                break;
            }
        }
        inventory.remove(removeItem);
        return removeItem;
    }

    public String toString() {
        StringBuilder res = new StringBuilder();
        res.append("Type/Name/Price/Properties\n");
        for (Item item : inventory) {
            res.append(item.getType()).append(item.getName()).append(item.getPrice());
            res.append("\n");
        }
        return res.toString();
    }

    public boolean ifContains(String name) {
        for (Item item : inventory) {
            if (item.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public Item getItemByName(String name) {
        Item returnItem = null;
        for (Item item : inventory) {
            if (item.getName().equals(name)) {
                returnItem = item;
                break;
            }
        }
        return returnItem;
    }
}
