//Class for heros

public class Hero extends Figure {

    private int mana;

    private int strength;

    private int dexterity;

    private int agility;

    private int money;

    private int exp;

    private int nextLevelExp;

    private Weaponry curWeaponry;

    private Armory curArmory;

    private boolean isFainted;

    private Inventory inventory;

    private boolean madeMove;

    private int INIT_NEXT_LEVEL_EXP = 15;

    private int INIT_LEVEL = 1;

    private int LEVEL_HP_MULTIPLY = 100;

    public Hero(String[] args) {
        //Name/mana/strength/agility/dexterity/starting money/starting experience
        super();
        setName(args[0]);
        setMana(Integer.parseInt(args[1]));
        setStrength(Integer.parseInt(args[2]));
        setAgility(Integer.parseInt(args[3]));
        setDexterity(Integer.parseInt(args[4]));
        setMoney(Integer.parseInt(args[5]));
        setExp(Integer.parseInt(args[5]));
        setNextLevelExp(INIT_NEXT_LEVEL_EXP);
        setLevel(INIT_LEVEL);
        setHp(INIT_LEVEL * LEVEL_HP_MULTIPLY);
    }

    public void addToInventory(Item item) {
        inventory.add(item);
    }

    public String toString() {
        return getName() + "   " + getMana() + "   " + getStrength() + "   " + getAgility() + "   " + getDexterity() + "   " + getMoney() + "   " + getExp();
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getDexterity() {
        return dexterity;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    public int getAgility() {
        return agility;
    }

    public void setAgility(int agility) {
        this.agility = agility;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getNextLevelExp() {
        return nextLevelExp;
    }

    public void setNextLevelExp(int nextLevelExp) {
        this.nextLevelExp = nextLevelExp;
    }

    public Weaponry getCurWeapon() {
        return curWeaponry;
    }

    public void setCurWeapon(Weaponry curWeaponry) {
        this.curWeaponry = curWeaponry;
    }

    public Armory getCurArmor() {
        return curArmory;
    }

    public void setCurArmor(Armory curArmory) {
        this.curArmory = curArmory;
    }
}
