//Class for firespells

public class FireSpells extends Spell {

    private int baseDamageDeduction;

    public FireSpells(String[] args) {
        super(args);
    }

}
