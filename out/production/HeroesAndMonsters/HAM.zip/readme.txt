Compilation & running instructions:
compile: javac *.java
run: java Main

Design patterns:
Factory pattern, used in HeroFactory and ItemFactory
Singleton Pattern, used in ItemFactory and MonsterFactory. Do not want more than 1, used only in Market & Common Cells.