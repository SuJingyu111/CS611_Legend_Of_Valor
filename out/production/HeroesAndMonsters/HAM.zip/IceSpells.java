//Class for icespells

public class IceSpells extends Spell {

    private int baseDamageDeduction;

    public IceSpells(String[] args) {
        super(args);
    }

}
