//Monster Exoskeleton

public class Exoskeletons extends Monster{
}
