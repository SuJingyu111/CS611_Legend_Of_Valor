//Class for potions

public class Potions extends Item{

    private int attributeIncrease;

    String[] influenceAttributes;

    public Potions(String[] args) {
        setName(args[0]);
        setPrice(Integer.parseInt(args[1]));
        setMinHeroLevel(Integer.parseInt(args[2]));
        attributeIncrease = Integer.parseInt(args[3]);
        influenceAttributes = args[4].split("/");
    }
}
