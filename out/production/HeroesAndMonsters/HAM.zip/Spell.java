//Abstract class for spells

public abstract class Spell extends Item{

    private String name;

    private int minHeroLevel;

    private int price;

    private int damage;

    private int manaCost;

    //public abstract void castInfluence (Figure fig);//TODO
    public Spell(String[] args) {
        name = args[0];
        price = Integer.parseInt(args[1]);
        minHeroLevel = Integer.parseInt(args[2]);
        damage = Integer.parseInt(args[3]);
        manaCost = Integer.parseInt(args[4]);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getMinHeroLevel() {
        return minHeroLevel;
    }

    @Override
    public void setMinHeroLevel(int minHeroLevel) {
        this.minHeroLevel = minHeroLevel;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getManaCost() {
        return manaCost;
    }

    public void setManaCost(int manaCost) {
        this.manaCost = manaCost;
    }
}
