//Monster Exoskeleton, inherits Monster

public class Exoskeletons extends Monster{

    public Exoskeletons(String[] args) {
        super(args);
    }

}
