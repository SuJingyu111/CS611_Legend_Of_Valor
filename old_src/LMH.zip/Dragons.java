//Monster Dragon, inherits Monster

public class Dragons extends Monster{

    public Dragons(String[] args) {
        super(args);
    }
}
