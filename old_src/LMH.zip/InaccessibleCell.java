//Class for cells that are not accessible, inherits Cell

public class InaccessibleCell extends Cell{
}
