//Class for monster spirit, inherits Monster

public class Spirits extends Monster{

    public Spirits(String[] args) {
        super(args);
    }

}
