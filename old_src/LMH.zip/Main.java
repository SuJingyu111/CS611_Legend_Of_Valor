//Main class that executes the code

public class Main {

    public static void main(String[] args) {
        LMH game = new LMH();
        game.play();
    }

}
